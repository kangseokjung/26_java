package day03;
import java.util.Scanner;

public class Ex05 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("숫자를 입력하세요:");
		int num = sc.nextInt();
		// 만약 짝수이면 짝수입니다., 아니면 홀수입니다.
		if(num % 2 == 0) {
			//참일때 실행문장
			System.out.println("짝수입니다.");
		}else { // 참이아닐때 실행문장
			System.out.println("홀수입니다.");
		}

	}

}
