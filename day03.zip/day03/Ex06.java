package day03;
import java.util.Scanner;

public class Ex06 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		//id,pwd 초기화
		String id ="hong", pwd="1234";
				
		System.out.println("아이디를 입력하세요:");
		String myid = sc.next();
		System.out.println("pwd를 입력하세요:");
		String mypwd = sc.next();
		// 만약 짝수이면 짝수입니다., 아니면 홀수입니다.
		if((myid.equals(id)) && (mypwd.equals(pwd))) {
			//참일때 실행문장
			System.out.println("로그인 완료");
		}else { // 참이아닐때 실행문장
			System.out.println("로그인 실패");
		}

	}

}
