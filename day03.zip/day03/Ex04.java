package day03;
import java.util.Scanner;

public class Ex04 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("숫자를 입력하세요:");
		int num = sc.nextInt();
		// 만약에 점수가 70점 이상이면 합겹., 아니면 불합겹
		if(num >= 70) {
			//참일때 실행문장
			System.out.println("합겹입니다.");
		}else { // 참이아닐때 실행문장
			System.out.println("불합격입니다.");
		}

	}

}
