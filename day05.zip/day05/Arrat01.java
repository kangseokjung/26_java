package day05;
import java.util.Scanner;
public class Arrat01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// 1차원 배열 선언
		int intArray [];
		// 배열 생성
		intArray = new int[5];
		int intMax = 0; // 가장 큰수 저장
		//양수 5개 입력받아 배열에 저장하고, 그중 가장 큰수 출력하기
		System.out.println("5개 양수 입력");
		for (int i = 0; i < intArray.length; i++) {
			intArray[i] = sc.nextInt();
			if(intArray[i] > intMax)
				intMax = intArray[i]; // 최대값 변경
			
		}
		System.out.println("가장 큰 수는 " + intMax + "입니다");

	}

}
