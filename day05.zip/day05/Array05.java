package day05;

import javax.annotation.processing.SupportedSourceVersion;

public class Array05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 2차원 배열 ... 4행 2열
		
		double score [][]= {{3.3,3.4},{3.5,3.6},{3.7,4.0},{4.1,4.2}};
		
		//평균 평점 구하기
		double sum = 0;
		
		try {
			for(int year = 0;year<4;year++) {
				for(int term=0;term<score[year].length;term++) {
					sum += score[year][term];
				}
			}
		}catch(ArrayIndexOutOfBoundsException ao) {
			ao.printStackTrace();
		}
		int n = score.length;
		int m = score[0].length;
		
		System.out.println(n-1 + "년 전체 평점 평균" + sum /(n*m));
	}
}
