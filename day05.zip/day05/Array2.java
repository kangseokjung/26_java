package day05;
import java.util.Scanner;
public class Array2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// 1차원 배열 선언
		int intArray [];
		// 배열 생성
		intArray = new int[5];
		//int intMax = 0; // 가장 큰수 저장
		int sum = 0;

		//양수 5개 입력받아 배열에 저장하고, 그중 가장 큰수 출력하기
		System.out.println("5개 양수 입력");
		for (int i = 0; i < intArray.length; i++) {
			intArray[i] = sc.nextInt();
			// 평균구하기 
			sum += intArray[i];
		}
		int avg = sum / intArray.length;
		
		
		
		System.out.println("평균값은 " + avg + "입니다.");

	}

}
