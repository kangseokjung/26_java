package day02;

public class Hello0310 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//print계열 메소드를 이용해 자바로 하고싶은 것 작성해서 출력하기
		System.out.println("웹,안드로이드 개발 혹은 머신러닝");
	}

}
